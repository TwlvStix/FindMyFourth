import '/utils/app_util.dart';
import '/auth/firebase_auth/auth_util.dart';
import '/core/widgets/app_button_enhanced.dart';
import '/core/widgets/fairway_background.dart';
import '/core/design_tokens/border_radius.dart';
import '/core/design_tokens/spacing.dart';
import '/core/design_tokens/colors.dart';
import '/core/design_tokens/typography.dart';
import 'dart:ui';
import '/models/game.dart';
import '/screens/trust/cancellation_warning_modal.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '/providers/provider_extensions.dart';

class LeaveGameWidget extends StatefulWidget {
  const LeaveGameWidget({
    super.key,
    required this.gameRef,
  });

  final Game gameRef;

  @override
  State<LeaveGameWidget> createState() => _LeaveGameWidgetState();
}

class _LeaveGameWidgetState extends State<LeaveGameWidget> {
  @override
  void initState() {
    super.initState();
    // ✅ PERFORMANCE: Removed empty post-frame setState (no-op rebuild)
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FairwayBackgroundDark(
      child: ClipRRect(
        child: BackdropFilter(
          filter: ImageFilter.blur(
            sigmaX: 6.0,
            sigmaY: 8.0,
          ),
          child: Container(
            width: double.infinity,
            height: double.infinity,
            decoration: BoxDecoration(
              color: AppColors.greenLight,
            ),
            alignment: AlignmentDirectional(0.0, 1.0),
            child: Column(
              mainAxisSize: MainAxisSize.max,
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Container(
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: AppColors.navy,
                    boxShadow: [
                      BoxShadow(
                        blurRadius: 7.0,
                        color: AppColors.overlayDark,
                        offset: Offset(
                          0.0,
                          -2.0,
                        ),
                      )
                    ],
                    borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(0.0),
                      bottomRight: Radius.circular(0.0),
                      topLeft: Radius.circular(AppBorderRadius.lg),
                      topRight: Radius.circular(AppBorderRadius.lg),
                    ),
                  ),
                  child: Padding(
                    padding: EdgeInsets.only(top: AppSpacing.xs),
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisSize: MainAxisSize.max,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              width: 60.0,
                              height: 3.0,
                              decoration: BoxDecoration(
                                color: AppColors.cloud,
                                borderRadius:
                                    BorderRadius.circular(AppBorderRadius.xs),
                              ),
                            ),
                          ],
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            left: AppSpacing.md,
                            top: AppSpacing.md,
                          ),
                          child: RichText(
                            textScaler: MediaQuery.of(context).textScaler,
                            text: TextSpan(
                              children: [
                                TextSpan(
                                  text: 'Are you sure you want to leave ',
                                  style: TextStyle(),
                                ),
                                TextSpan(
                                  text: valueOrDefault<String>(
                                    widget.gameRef.nameGame,
                                    'game name',
                                  ),
                                  style: TextStyle(),
                                )
                              ],
                              style: AppTypography.headlineMediumSans.copyWith(
                                letterSpacing: 0.0,
                              ),
                            ),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(bottom: 1.0),
                          child: Container(
                            width: double.infinity,
                            decoration: BoxDecoration(
                              color: AppColors.pure,
                            ),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.fromLTRB(
                            AppSpacing.md,
                            AppSpacing.md,
                            AppSpacing.md,
                            44.0,
                          ),
                          child: AppButtonEnhanced(
                            onPressed: () async {
                              // Show tier-aware cancellation warning before proceeding
                              final confirmed =
                                  await CancellationWarningModal.show(
                                context,
                                game: widget.gameRef,
                              );
                              if (confirmed != true) return;
                              if (!context.mounted) return;

                              final currentUserId = currentUserUid;
                              if (currentUserId.isEmpty) {
                                showSnackbar(
                                  context,
                                  'Please sign in to leave this game.',
                                );
                                return;
                              }
                              try {
                                await context.gameProvider.leaveGame(
                                  widget.gameRef.reference.id,
                                  currentUserId,
                                );
                              } on FirebaseException catch (error) {
                                if (!context.mounted) return;
                                final message = error.code ==
                                        'permission-denied'
                                    ? 'You do not have permission to leave this game.'
                                    : 'Unable to leave the game right now. Please try again.';
                                showSnackbar(context, message);
                                return;
                              } catch (_) {
                                if (!context.mounted) return;
                                showSnackbar(
                                  context,
                                  'Unable to leave the game right now. Please try again.',
                                );
                                return;
                              }

                              if (!context.mounted) return;
                              context.pushSuccessPage(
                                transition: TransitionStandards.modalTransition,
                              );
                            },
                            text: 'Cancel My Spot',
                            variant: AppButtonVariant.secondary,
                            size: AppButtonSize.large,
                            fullWidth: true,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
