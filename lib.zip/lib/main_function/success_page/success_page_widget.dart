import '/utils/app_util.dart';
import '/core/widgets/app_button_enhanced.dart';
import '/core/widgets/fairway_background.dart';
import '/core/design_tokens/spacing.dart';
import '/core/design_tokens/colors.dart';
import '/core/design_tokens/typography.dart';
import '/core/design_tokens/icon_size.dart';
import '/core/design_tokens/app_phosphor_icons.dart';
import '/core/widgets/app_icon.dart';
import 'package:flutter/material.dart';

class SuccessPageWidget extends StatefulWidget {
  const SuccessPageWidget({super.key});

  static String routeName = 'success_page';
  static String routePath = '/successPage';

  @override
  State<SuccessPageWidget> createState() => _SuccessPageWidgetState();
}

class _SuccessPageWidgetState extends State<SuccessPageWidget> {
  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    // ✅ PERFORMANCE: Removed empty post-frame setState (no-op rebuild)
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      backgroundColor: AppColors.navy,
      body: FairwayBackgroundClubhouse(
        child: SafeArea(
          top: true,
          child: Row(
            mainAxisSize: MainAxisSize.max,
            children: [
              Expanded(
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Padding(
                      padding: AppSpacing.only(top: AppSpacing.xxxxl * 2.34),
                      child: Container(
                        width: 140.0,
                        height: 140.0,
                        decoration: BoxDecoration(
                          color: AppColors.navyDark,
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: AppColors.pure,
                            width: 2.0,
                          ),
                        ),
                        alignment: AlignmentDirectional(0.0, 0.0),
                        child: Padding(
                          padding: EdgeInsets.all(AppSpacing.xl + 6.0),
                          child: AppIcon(
                            icon: AppPhosphorIcons.check,
                            color: AppColors.pure,
                            size: AppIconSize.hero,
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding: AppSpacing.only(top: AppSpacing.xl),
                      child: Text(
                        'You are in!',
                        style: AppTypography.titleLarge,
                      ),
                    ),
                    Padding(
                      padding: AppSpacing.only(top: AppSpacing.md),
                      child: Text(
                        'Enjoy the Game',
                        style: AppTypography.titleLarge,
                      ),
                    ),
                    Padding(
                      padding: AppSpacing.only(top: AppSpacing.md),
                      child: Text(
                        'Enjoy the Group',
                        style: AppTypography.titleLarge,
                      ),
                    ),
                    Expanded(
                      child: Padding(
                        padding: AppSpacing.only(bottom: AppSpacing.xxl),
                        child: Column(
                          mainAxisSize: MainAxisSize.max,
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            AppButtonEnhanced(
                              onPressed: () async {
                                context.pushGamesList(
                                  transition:
                                      TransitionStandards.flatFadeTransition,
                                );
                              },
                              text: 'Go to Game Lists',
                              variant: AppButtonVariant.primary,
                              size: AppButtonSize.large,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
