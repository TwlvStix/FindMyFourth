import 'dart:io';

import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/backend/firebase_storage/storage.dart';
import '/utils/app_util.dart';
import '/utils/profile_image_picker.dart';
import '/core/widgets/app_button_enhanced.dart';
import '/core/design_tokens/spacing.dart';
import '/core/design_tokens/colors.dart';
import '/core/design_tokens/typography.dart';
import '/utils/upload_data.dart';
import '/core/design_tokens/border_radius.dart';
import 'package:flutter/material.dart';

class ChangePhotoWidget extends StatefulWidget {
  const ChangePhotoWidget({super.key});

  @override
  State<ChangePhotoWidget> createState() => _ChangePhotoWidgetState();
}

class _ChangePhotoWidgetState extends State<ChangePhotoWidget> {
  bool isDataUploadingUploadDataJ3j = false;
  UploadedFile uploadedLocalFileUploadDataJ3j =
      UploadedFile(bytes: Uint8List.fromList([]), originalFilename: '');
  String uploadedFileUrlUploadDataJ3j = '';

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.navy,
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(AppBorderRadius.lg),
        ),
      ),
      child: SafeArea(
        top: false,
        child: Padding(
          padding: EdgeInsets.fromLTRB(
            AppSpacing.lg,
            AppSpacing.sm,
            AppSpacing.lg,
            AppSpacing.lg,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Drag handle
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  margin: EdgeInsets.only(bottom: AppSpacing.md),
                  decoration: BoxDecoration(
                    color: AppColors.navyLight,
                    borderRadius: BorderRadius.circular(AppBorderRadius.xxs),
                  ),
                ),
              ),
              // Title
              Text(
                'Change Profile Picture',
                style: AppTypography.headlineMediumSans.copyWith(
                  fontWeight: FontWeight.bold,
                  letterSpacing: 0.0,
                  color: AppColors.textPrimary,
                ),
              ),
              // Description
              Padding(
                padding: EdgeInsets.only(top: AppSpacing.xs),
                child: Text(
                  'Upload a new photo below in order to change your profile picture.',
                  style: AppTypography.labelMedium.copyWith(
                    color: AppColors.textSecondary,
                  ),
                ),
              ),
              // Avatar
              Padding(
                padding: EdgeInsets.only(top: AppSpacing.md),
                child: Center(
                  child: Container(
                    width: 100.0,
                    height: 100.0,
                    decoration: BoxDecoration(
                      color: AppColors.mist,
                      shape: BoxShape.circle,
                    ),
                    child: Stack(
                      children: [
                        Padding(
                          padding: EdgeInsets.all(AppSpacing.xxs),
                          child: AuthUserStreamWidget(
                            builder: (context) => Container(
                              width: 120.0,
                              height: 120.0,
                              clipBehavior: Clip.antiAlias,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                              ),
                              child: Image.network(
                                valueOrDefault<String>(
                                  currentUserPhoto,
                                  'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_1280.png',
                                ),
                                fit: BoxFit.cover,
                                errorBuilder:
                                    (context, error, stackTrace) =>
                                        Container(
                                  color: AppColors.navyLight,
                                  child: Icon(
                                    Icons.person,
                                    size: 60,
                                    color: AppColors.textMuted,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Padding(
                          padding: AppSpacing.allXxs,
                          child: Container(
                            width: 120.0,
                            height: 120.0,
                            clipBehavior: Clip.antiAlias,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                            ),
                            child: Image.network(
                              valueOrDefault<String>(
                                uploadedFileUrlUploadDataJ3j,
                                'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_1280.png',
                              ),
                              fit: BoxFit.cover,
                              errorBuilder:
                                  (context, error, stackTrace) =>
                                      Container(
                                color: AppColors.navyLight,
                                child: Icon(
                                  Icons.person,
                                  size: 60,
                                  color: AppColors.textMuted,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              // Buttons
              Padding(
                padding: EdgeInsets.only(top: AppSpacing.xl),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    AppButtonEnhanced(
                      onPressed: () async {
                        final croppedPath =
                            await showProfileImageSourceSheet(
                                context);
                        if (croppedPath == null) return;

                        if (mounted) {
                          setState(() =>
                              isDataUploadingUploadDataJ3j = true);
                        }
                        try {
                          final bytes = await File(croppedPath)
                              .readAsBytes();
                          final storagePath =
                              'users/$currentUserUid/profile_photos/${DateTime.now().millisecondsSinceEpoch}.jpg';
                          final downloadUrl =
                              await uploadData(storagePath, bytes);
                          if (downloadUrl != null && mounted) {
                            setState(() {
                              uploadedFileUrlUploadDataJ3j =
                                  downloadUrl;
                            });
                          }
                        } finally {
                          if (mounted) {
                            setState(() =>
                                isDataUploadingUploadDataJ3j =
                                    false);
                          }
                        }
                      },
                      text: 'Upload Image',
                      variant: AppButtonVariant.secondary,
                      size: AppButtonSize.medium,
                    ),
                    AppButtonEnhanced(
                      onPressed: () async {
                        if (isDataUploadingUploadDataJ3j) {
                          showUploadMessage(
                            context,
                            'Upload in progress. Please wait.',
                          );
                          return;
                        }
                        if (uploadedFileUrlUploadDataJ3j.isEmpty) {
                          showUploadMessage(
                            context,
                            'Please upload a photo before saving.',
                          );
                          return;
                        }
                        final userRef = currentUserReference;
                        if (userRef == null) return;
                        await userRef.update(createUsersRecordData(
                          photoUrl:
                              uploadedFileUrlUploadDataJ3j,
                        ));
                        if (!context.mounted) return;
                        Navigator.pop(context);
                      },
                      text: 'Save Changes',
                      variant: AppButtonVariant.primary,
                      size: AppButtonSize.medium,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
